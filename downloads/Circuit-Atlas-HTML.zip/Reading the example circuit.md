# Understand the PSU status circuit in the worked example

Start with **PDF page 23, drawing 039, revision F**. This is the physical power-supply arrangement: PULS PSU A, PULS PSU B, and a redundancy module. The power supplies' terminals **13 and 14** are identified as **DC ok** on the equipment illustration; the connected status wiring is labelled **PSU FAULT**.

At the upper right, the continuation marked **098.275** has the connection identifier **1109:d28**. Click that reference, or its associated connection label, in the viewer. The documented destination is **PDF page 67, drawing 098, revision E**, where the upper-right circuit carries the reciprocal reference **039.377**. PDF page numbers and printed drawing numbers are different: the viewer shows both.

## Read the destination from left to right

The upper-right circuit on drawing 098 shows:

1. The rail labelled **4L+** enters the **PULS PSU B** contact at terminal **13**, leaving at **14**.
2. That line continues through the **PULS PSU A** contact, from **14** to **13**. The two contacts are drawn in series and collectively labelled **PSU FAULT**.
3. After the contacts, the line reaches the **HIMA F3236** digital input module through **I/O plug Z7116**. Its table identifies **pin d28**, **channel 14**, and **position 1109**. This agrees with the source connection identifier **1109:d28**.
4. A branch from that same downstream line feeds the indicator labelled **24V DC SUPPLY FAULT**, with **Y** beside the indicator symbol. The other side of the indicator returns to **4L−**. The branch junction is explicitly drawn.

The drawing also identifies the F3236 as a **16-channel testable digital input module**. The segment toward its input is marked **0.5mmSq GREY**.

```mermaid
flowchart LR
    Supply["4L+"] --> B["PULS PSU B contact\n13 → 14"]
    B --> A["PULS PSU A contact\n14 → 13"]
    A --> Junction(("junction"))
    Junction --> Plug["I/O plug Z7116"]
    Plug --> Input["HIMA F3236\nPosition 1109 · CH 14 · pin d28"]
    Junction --> Lamp["24V DC SUPPLY FAULT indicator\nDrawing designation Y"]
    Lamp --> Return["4L−"]
```

This diagram summarizes the visible upper-right circuit on drawing 098; it does not add connections or represent signal timing. Use the original drawing for all terminal and equipment details.

## What this tells us about function

This is a power-supply status circuit presented to a PLC digital input and a panel indication. The series arrangement means the path through the two depicted contacts depends on both contact states. Following the reciprocal references links the equipment-level DC-ok terminals on drawing 039 to the PLC-input representation on drawing 098.

The labels alone do **not** establish whether a high or low PLC input means a fault. In particular, **DC ok** on the power supply and **PSU FAULT** on the circuit are different descriptions of the same documented status path, not enough information to establish its logical polarity. The drawn contact position does not report its present operating state.

These pages do not establish current supply voltage, whether either supply is healthy, the PLC's interpretation of input 1109:d28, any alarm delay or latching behaviour, or whether that input initiates a trip. Establish those from the applicable PSU documentation, PLC program, cause-and-effect specification, and measured or otherwise verified operating conditions. The viewer traces the documented circuit; it does not simulate or certify those functions.

## Use the viewer to investigate further

- Search **1109:d28**, **039.377**, or **098.275** to revisit the supporting evidence.
- Read the destination's **position/channel/pin** table, rather than treating a bare number such as 14 as a unique identifier across the entire drawing set.
- Use **Back** to compare the equipment terminals with the PLC input without losing the original position.
- Continue a trace only through a documented reference or a link you explicitly review. A repeated **4L+** label, repeated terminal number, or a line crossing alone is not sufficient evidence for a new electrical connection.
- Record an annotation with the source drawing and revision when you confirm an interpretation. Keep open questions such as input polarity visible until the supporting documents resolve them.
