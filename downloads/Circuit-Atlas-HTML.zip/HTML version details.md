# Open Circuit Atlas as an HTML file

The prepared drawing set is available as **Circuit-Atlas-Standalone.html**. It contains the user interface, all 135 drawing pages, the searchable CAD index and the documented connection evidence. You do not need Python, a command window, an installed application or a web server to use this edition.

## Start

1. Download `Circuit-Atlas-HTML.zip` and choose **Extract All**.
2. Open `Circuit-Atlas-Standalone.html` in a current version of **Microsoft Edge** or **Google Chrome**. Double-click it, or right-click it and choose **Open with**.
3. Allow a few seconds to open the prepared index. Click **Try supplied example** to start on drawing 039.
4. Click reference `098.275` or its attached wire. Drawing 098 opens, highlighting `039.377`. Use the viewer's **Back** button to return to the exact source view.

The single HTML file can also be downloaded directly. Keep the `.html` file extension. There are no companion drawing folders to configure, and the viewer does not download fonts, scripts, drawings or other assets.

## What you can do

Search the complete prepared set; view the original vector drawings; follow supported references or select among candidates; zoom/pan; use coloured and pulsing highlights; inspect CAD attributes; record notes; create reference markers; confirm or reject manual links; bookmark views; and export your investigation.

There are 135 viewable pages, 128 validated CAD overlays and 28,619 indexed appearances. The same conservative connection rules apply: one genuine reciprocal circuit pair supports automatic documented tracing. Repeated labels remain candidates. Seven uncertain page overlays remain withheld. The original source documents have not been changed.

## Keep your review work

Notes, manual markers and reviewed links are saved in this browser's storage when available. They are **not written back into the HTML file**. Browser storage may be cleared or may differ when you move the file, change browsers or use a private window. The viewer reports if storage is unavailable.

Use **Export review backup** to download a JSON file before moving the HTML or clearing browser data. In the new browser/location, choose **Restore review backup** and select that JSON file. The viewer checks that the backup belongs to the same prepared drawing index, then merges notes, markers and manual links. A newer review of the same link takes priority.

The export also contains your current trace as a readable record. Trace navigation history is not restored as an active session, and bookmarks remain in the browser where they were created.

## Prepared drawings versus new imports

This HTML edition opens the drawings already prepared for this project. It does **not** extract or register a new PDF/DXF drawing set in the browser. Adding new drawings requires a new prepared HTML package or the separate Python application. The **Restore review backup** button imports review JSON, not new drawings.

## Verification limits

All **four standalone browser tests passed** in Chromium: actual cross-reference and conductor clicks, full-set search and page 135 rendering, real review persistence and backup export/restore, and rejection propagation plus wrong-dataset backup rejection. The original server interface also passed its four browser regression tests after these changes.

The managed cloud browser blocks `file://` URLs by administrator policy. Testing therefore uses an allowed local connection that serves **only this HTML document**; no application backend, API endpoints or external assets are involved. Direct double-click/file-URL launching on your Windows computer remains unverified here. No browser policy was disabled or bypassed.

The content-security policy in the HTML disables application network connections. All embedded page SVGs were decompressed and checked against the prepared views of the original PDF. Test evidence is in `offline-test-results.txt` and `html-integrity-results.json`.

## For maintainers

`python tools/build_standalone.py` creates the self-contained HTML from the validated local project. Python is a **build-time tool**, not a dependency for opening the resulting file. The builder refuses to embed a project with personal review annotations; export those separately and restore them through the HTML viewer.

Ordinary-browser tests use `python -m unittest discover -s tests -p test_offline.py -v`. In a managed test browser that blocks local file URLs, set `CIRCUIT_ATLAS_HTTP_TEST=1` to select the explicitly reported static-document test mode. This mode does not establish direct file-launch compatibility.
